const express = require("express"); 
const bodyParser = require("body-parser"); // Url dat and json data handle
var fs = require('fs');
const { json } = require("body-parser");

const mongoose = require('mongoose'); 
const { mongo } = require('mongoose');


mongoose.connect("mongodb://localhost:27017/UKI_4KC").then((db)=>{
    console.log("db connect");
})
  .catch((err)=>{
    console.log(err);
  })

  const NewSchema= new mongoose.Schema({
    userid:String,
    name:String,
    age:Number,
    city:String,
    nic:String
   
  })



 

  const app = express();
  
app.use(bodyParser.urlencoded({
    extended: true
}));

app.get("/",function(req,res){
    res.sendFile(__dirname + "/post.html");

});

app.post("/action_page",function(req,res){
    var name=req.body.name;
    var age=req.body.age;
    var city =req.body.city;
    var nic =req.body.nic;
    var obj={};
    var key = req.body.userid;
    var newUser={
        "name":name,
        "age":age,
        "city":city,
        "nic":nic
    }

    obj[key] = newUser;

    


    fs.readFile("user.json","utf8",function(err,data){

        data = JSON.parse(data);
        data[key]=obj[key];
        console.log(data);
        var updateuser = JSON.stringify(data);
        fs.writeFile("user.json",updateuser,function(err){
            res.end(JSON.stringify(data));

        });
    });


    const newModel=new mongoose.model("Studentdetails",NewSchema);
    const datas=new newModel(newUser);
    datas.save();
  
  
});
app.listen(8080,function(){
    console.log("server is running part 8080");
});

